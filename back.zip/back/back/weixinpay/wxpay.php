<?php 
    require_once "lib/WxPay.Api.php";
    require_once "lib/WxPay.Config.php";
    require_once "lib/WxPay.Data.php";
    require_once "lib/WxPay.Exception.php";
    require_once "lib/WxPay.Notify.php";
    require_once "example/WxPay.JsApiPay.php";
    require_once "example/log.php";
    require_once "example/notify.php";
 ?>