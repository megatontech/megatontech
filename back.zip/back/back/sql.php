<?php 
header("Content-Type: text/html;charset=utf-8");
$mysql_conf = array(
    'host'    => '127.0.0.1', 
    'db'      => '6758', 
    'db_user' => 'root', 
    'db_pwd'  => 'zml6758', 
    );
$mysql_conn = @mysql_connect($mysql_conf['host'], $mysql_conf['db_user'], $mysql_conf['db_pwd']);
if (!$mysql_conn) {
    die("could not connect to the database:\n" . mysql_error());//诊断连接错误
}
mysql_query("set names 'utf8'");//编码转化
$select_db = mysql_select_db($mysql_conf['db']);
if (!$select_db) {
    die("could not connect to the db:\n" .  mysql_error());
}
$name = $_POST['text'];
$time = $_POST['time'];
$sql = "select * from like_data where 大学名称 = '$name' and 年份 ='$time' and 大学及专业代码 like 'Z%' order by 批次 desc,最低分 asc";

$res = mysql_query($sql);

$jarr = array();

while ($rows=mysql_fetch_array($res,MYSQL_ASSOC)){

  $count=count($rows);

  for($i=0;$i<$count;$i++){ 

    unset($rows[$i]);

  }

  array_push($jarr,$rows);

}


$sql1 = "select * from biaozhuidaxue where 大学名称 = '$name' ";
$res1 = mysql_query($sql1);
$rows1 = mysql_fetch_array($res1);
$date['info'] = $rows1;
$date['list'] = $jarr;
echo json_encode($date);

?>