<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>6758志愿填报系统</title>
<style type="text/css">
<!--
.STYLE1 {
	font-size: xx-large;
	color: #FF0000;
}
.STYLE2 {color: #FF00FF}
.STYLE3 {font-size: 12px}
-->
</style>
<style type="text/css">
.search_text{ overflow:hidden; height:100%; padding-top:5px; padding-bottom:5px;}
.search_text h1{ color:#6a6a6a; font-weight:bold; float:left; font-size:16px; margin:0px; padding:0px;}
.search_text ul{ margin:0; padding:0; list-style:none; float:left; overflow:hidden; height:100%;}
.search_text li{ list-style:none; color:#6a6a6a; float:left;font-size:14px; width:50px; padding-left:80px; padding-right:5px; white-space:nowrap}
.search_text li a{ list-style:none; color:#6a6a6a;}
.search_text li a:hover{ list-style:none; color:#fe8f01; font-weight:bold; text-decoration:underline;}
.search_text li.selected{color:#fe8f01; font-weight:bold;}
.search_text li.selected a{color:#fe8f01;}
.search_text li.selected a:hover{color:#fe8f01;}
//
.search_text1{ overflow:hidden; height:100%; padding-top:5px; padding-bottom:5px;}
.search_text1 h1{ color:#6a6a6a; font-weight:bold; float:left; font-size:16px; margin:0px; padding:0px;}
.search_text1 ul{ margin:0; padding:0; list-style:none; float:left; overflow:hidden; height:100%;}
.search_text1 li{ list-style:none; color:#6a6a6a; float:left; font-size:14px;width:50px; padding-left:8px; padding-right:5px; white-space:nowrap}
.search_text1 li a{ list-style:none; color:#6a6a6a;}
.search_text1 li a:hover{ list-style:none; color:#fe8f01; font-weight:bold; text-decoration:underline;}
.search_text1 li.selected{color:#fe8f01; font-weight:bold;}
.search_text1 li.selected a{color:#fe8f01;}
.search_text1 li.selected a:hover{color:#fe8f01;}
</style>
</head>
<body>

<a href="../../yx.php">院校列表</a>|<a href="./index.php/Home/index/index">专业列表</a>|6758智能报考
<?php
/*
 <ul>
      <li <?php if (!isset($_GET['year']) || $_GET['year'] == 0) { ?>class="selected"<?php } ?>><a href="javascript:goSort('year',0)">全部</a></li>
      <li <?php if (isset($_GET['year'] && $_GET['year'] == 1) { ?>class="selected"<?php } ?>><a href="javascript:goSort('year',1)">2015</a></li>
      <li <?php if (isset($_GET['year'] && $_GET['year'] == 2) { ?>class="selected"<?php } ?>><a href="javascript:goSort('year',2)">2014</a></li>
    </ul>
*/
?>
<div class="search_text" id="pici">
    <h1>批  次：</h1>
		<ul>
          <li <?php if (!isset($_GET['pici']) || $_GET['pici'] == "全部") { ?>class="selected"<?php } ?>><a href="javascript:goSort('pici','全部')">全部</a></li>
          <li <?php if (!isset($_GET['pici']) || $_GET['pici'] == "一批") { ?>class="selected"<?php } ?>><a href="javascript:goSort('pici','一批')">一批</a></li>
		  <li <?php if (!isset($_GET['pici']) || $_GET['pici'] == "二批") { ?>class="selected"<?php } ?>><a href="javascript:goSort('pici','二批')">二批</a></li>
		  <li <?php if (!isset($_GET['pici']) || $_GET['pici'] == "提前批A") { ?>class="selected"<?php } ?>><a href="javascript:goSort('pici','提前批A')">提前批A</a></li>
		  <li <?php if (!isset($_GET['pici']) || $_GET['pici'] == "提前批B") { ?>class="selected"<?php } ?>><a href="javascript:goSort('pici','提前批B')">提前批B</a></li>
		  <li <?php if (!isset($_GET['pici']) || $_GET['pici'] == "地方专项") { ?>class="selected"<?php } ?>><a href="javascript:goSort('pici','地方专项')">地方专项</a></li>
		  <li <?php if (!isset($_GET['pici']) || $_GET['pici'] == "体育提前批A") { ?>class="selected"<?php } ?>><a href="javascript:goSort('pici','体育提前批A')">体育提前批A</a></li>
		  <li <?php if (!isset($_GET['pici']) || $_GET['pici'] == "体育提前批B") { ?>class="selected"<?php } ?>><a href="javascript:goSort('pici','体育提前批B')">体育提前批B</a></li>
		  <li <?php if (!isset($_GET['pici']) || $_GET['pici'] == "体育提二批") { ?>class="selected"<?php } ?>><a href="javascript:goSort('pici','体育提二批')">体育提二批</a></li>
        </ul> 
</div> 
<div class="search_text1" id="province">
    <h1>省份：</h1>
		<ul>	
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "全国") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','全国')">全国</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "北京") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','北京')">北京</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "上海") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','上海')">上海</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "天津") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','天津')">天津</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "重庆") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','重庆')">重庆</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "辽宁") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','辽宁')">辽宁</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "吉林") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','吉林')">吉林</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "黑龙江") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','黑龙江')">黑龙江</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "山东") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','山东')">山东</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "河南") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','河南')">河南</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "河北") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','河北')">河北</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "山西") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','山西')">山西</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "陕西") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','陕西')">陕西</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "江苏") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','江苏')">江苏</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "浙江") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','浙江')">浙江</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "江西") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','江西')">江西</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "安徽") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','安徽')">安徽</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "海南") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','海南')">海南</a></li> 
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "湖北") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','湖北')">湖北</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "湖南") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','湖南')">湖南</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "福建") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','福建')">福建</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "广东") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','广东')">广东</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "四川") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','四川')">四川</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "广西") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','广西')">广西</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "云南") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','云南')">云南</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "甘肃") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','甘肃')">甘肃</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "贵州") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','贵州')">贵州</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "青海") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','青海')">青海</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "新疆") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','新疆')">新疆</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "内蒙古") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','内蒙古')">内蒙古</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "宁夏") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','宁夏')">宁夏</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "西藏") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','西藏')">西藏</a></li>
			<li <?php if (!isset($_GET['province']) || $_GET['province'] == "香港") { ?>class="selected"<?php } ?>><a href="javascript:goSort('province','香港')">香港</a></li>
		</ul> 
</div>
<div class="search_text1" id="year">
    <h1>年  份：</h1>
		<ul>
		  <li <?php if (!isset($_GET['year']) || $_GET['year'] == "全部") { ?>class="selected"<?php } ?>><a href="javascript:goSort('year','全部')">全部</a></li>
          <li <?php if (!isset($_GET['year']) || $_GET['year'] == "2015") { ?>class="selected"<?php } ?>><a href="javascript:goSort('year','2015')">2015</a></li>
          <li <?php if (!isset($_GET['year']) || $_GET['year'] == "2016") { ?>class="selected"<?php } ?>><a href="javascript:goSort('year','2016')">2016</a></li>
		  <li <?php if (!isset($_GET['year']) || $_GET['year'] == "2017") { ?>class="selected"<?php } ?>><a href="javascript:goSort('year','2017')">2017</a></li>
		  <li <?php if (!isset($_GET['year']) || $_GET['year'] == "2018") { ?>class="selected"<?php } ?>><a href="javascript:goSort('year','2018')">2018</a></li>
		  <li <?php if (!isset($_GET['year']) || $_GET['year'] == "2019") { ?>class="selected"<?php } ?>><a href="javascript:goSort('year','2019')">2019</a></li>
        </ul> 
</div>
 
<div class="search_text1" id="kebie">
    <h1>科 别：</h1>
		<ul>
          <li <?php if (!isset($_GET['kebie']) || $_GET['kebie'] == 0) { ?>class="selected"<?php } ?>><a href="javascript:goSort('kebie',0)">文科</a></li>
          <li <?php if (!isset($_GET['kebie']) || $_GET['kebie'] == 1) { ?>class="selected"<?php } ?>><a href="javascript:goSort('kebie',1)">理科</a></li>
        </ul> 
</div>
<div class="search_text1" id="paixu">
    <h1>排 序：</h1>
		<ul>
          <li <?php if (!isset($_GET['paixu']) || $_GET['paixu'] == '最低分') { ?>class="selected"<?php } ?>><a href="javascript:goSort('paixu','最低分')">最低分</a></li>
          <li <?php if (!isset($_GET['paixu']) || $_GET['paixu'] == '平均分') { ?>class="selected"<?php } ?>><a href="javascript:goSort('paixu','平均分')">平均分</a></li>
        </ul> 
</div>
 <table width="100%" border="1" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
 
   
 
<?php
		/**
	*加入搜索条件
	*/
	$where ="1";
	$year_array = array(1=>'2017',2=>'2016');
	$ctype_array = array(1=>'0',2=>'1');
	$colors_array = array(1=>'0',2=>'1',3=>'2',4=>'3',5=>'4',6=>'5');
	$lengths_array = array(1=>'0',2=>'1',3=>'2',4=>'3',5=>'4',6=>'5',7=>'6');
	$micronaire_array = array(1=>'0',2=>'1',3=>'2',4=>'3',5=>'4');
	if(isset($year)&&($year!=0)) $where .= " AND 年份 = ".$year_array[$year];
	if(isset($ctype)&&($ctype!=0)) $where .= " AND ctype=".$ctype_array[$ctype];
	if(isset($colors)&&($colors!=0)) $where .= " AND colors=".$colors_array[$colors];
	if(isset($lengths)&&($lengths!=0)) $where .= " AND lengths=".$lengths_array[$lengths];
	if(isset($micronaire)&&($micronaire!=0)) $where .= " AND micronaire=".$micronaire_array[$micronaire];
												
	/**
	*加入搜索条件
	//and like_data.大学名称 = '北京大学'" 
	*/
   /*
	$conn=mysql_connect("localhost","root","zml6758"); 
	mysql_select_db("6758",$conn); 
	mysql_query("set names utf8"); 
	
	$sql = "SELECT *
			FROM like_data  ,biaozhuidaxue 
			where   like_data.大学名称  =  biaozhuidaxue.大学名称
			and like_data.大学及专业代码 like 'S%'";
			
    $sql_page = "SELECT count(1)
			FROM like_data  ,biaozhuidaxue 
			where   like_data.大学名称  =  biaozhuidaxue.大学名称
			and like_data.大学及专业代码 like 'S%'"; 
	*/
	$sql = "select * from like_data where 大学及专业代码 like 'S%'";	
	$sql_page = "select count(1) from like_data where 大学及专业代码 like 'S%'";
	/*如果是第一次登录*/
	$oldurl = urldecode($_SERVER['REQUEST_URI']); 
	if(strpos($oldurl,"?") == false)
	{
		/*
	 	$sql = "SELECT *
			FROM like_data  ,biaozhuidaxue 
			where   like_data.大学名称  =  biaozhuidaxue.大学名称
			and like_data.大学及专业代码 like 'S%'
			and like_data.大学名称 = '北京大学'";
		$sql_page = "SELECT count(1)
			FROM like_data  ,biaozhuidaxue 
			where   like_data.大学名称  =  biaozhuidaxue.大学名称
			and like_data.大学及专业代码 like 'S%'
			and like_data.大学名称 = '北京大学'"; 
			*/
			$sql = "SELECT *
			FROM like_data  
			where  大学及专业代码 like 'S%'
			and 批次 = '一批'
			and 年份 = '2017'";
			 
		$sql_page = "SELECT count(1)
			FROM like_data   
			where 大学及专业代码 like 'S%'
			and 批次 = '一批'
			and 年份 = '2017'";
			
	}
	
     
	/*加入搜索条件*/		
	if (isset($_GET['province'])&& ($_GET['province'] != '全国')) 
	{$sql .= sprintf (" and 省份 = '%s'",$_GET['province']);
     $sql_page .= sprintf (" and 省份 = '%s'",$_GET['province']);
    } 
	if (isset($_GET['pici'])&& ($_GET['pici'] != '全部'))
	{$sql .= sprintf (" and 批次 = '%s'",$_GET['pici']);
     $sql_page .= sprintf (" and 批次 = '%s'",$_GET['pici']);
    }
	if (isset($_GET['year'])&& is_numeric($_GET['year'])) 
	{$sql .= ' and 年份 = '.$_GET['year'];
     $sql_page .= ' and 年份 = '.$_GET['year'];
    }
	if (isset($_GET['paixu'])) {$sql .= sprintf (" order by %s desc ",$_GET['paixu']);} 
	    else {$sql .= sprintf (" order by 最低分 desc ");}
		
		/* 计算显示的页数开始
	 */
	 //获取当前页码
	 if (isset($_GET['page']))
	 {$page=$_GET['page'];}
      else {$page = 0;}
        if($page==0){
            $page=1;
        }
        //设置每页最大能显示的数量
        $pagesize=10; 
        //获取结果集的记录数
			
		$result_page = 	mysql_query($sql_page);
        $row_page = mysql_fetch_row($result_page);
        $recordcount=$row_page[0];  

        //计算总页数
        if($recordcount==0)
            $pagecount=0;
        else if($recordcount<$pagesize ||$recordcount==$pagesize){
                $pagecount=1;
                //如果 记录 总数 量小 于 每页 显示 的 记录 数量， 则 只有 一页
            }
        else if($recordcount%$pagesize==0){
                $pagecount=$recordcount/$pagesize;
                //如果 没有 余数， 则 页数 等于 总 记录 数量 除以 每页 显示 记录 的 数量
            }
        else 
                $pagecount=(int)($recordcount/$pagesize)+1;
                //取 记录 总数 量 不能 整除 每页 显示 记录 的 数量，
                // 则 页数 等于 总 记录 数量 除以 每页 显示 记录 数量 的 结果 取整 再加 1

       // echo("当前页码：".$page."/".$pagecount."<br />");
	 
	 /*计算显示的页数结束
	 */
	
	$sql .= sprintf("limit %u,%u ",($page-1)*$pagesize,$pagesize);
	//echo 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']; 
	$result = mysql_query($sql);
	 
	    echo"<tr>";
	    echo'<td width="25%" align="left"><a>大学名称</a></td>'; 
		echo'<td width="5%" align="left"><a>省份</a></td>';
		echo'<td width="5%" align="left"><a>211标识</a></td>';
        echo'<td width="5%" align="left"><a>985标识</a></td>';
        echo'<td width="3%" align="left"><a>录取人数</a></td>';  
		echo'<td width="3%" align="left"><a>最高分</a></td> ';
        echo'<td width="3%" align="left"><a>最低分</a></td>';
        echo'<td width="3%" align="left"><a>平均分</a></td> '; 
		echo'<td width="3%" align="left"><a>差值</a></td> ';
        echo'<td width="4%" align="left"><a>最高分省排名</a></td>';
        echo'<td width="4%" align="left"><a>最低分省排名</a></td> '; 
		echo'<td width="4%" align="left"><a>平均分省排名</a></td> ';
        echo'<td width="4%" align="left"><a>年份</a></td>';
        echo'<td width="5%" align="left"><a>批次</a></td> '; 
		echo'<td width="19%" align="left"><a>备注</a></td>';
        echo"</tr>";
	while($row = mysql_fetch_array($result))
		{ 
			 echo"<tr>";
			// //echo'<td width="3%" align="left" ><a>'.strlen($row['大学及专业代码']).'</a></td>'; 
			 echo'<td id = "schoolname" width="25%" align="left" ><a  href="javascript:void(0)"  class="dian" onclick="hello()">'.$row['大学名称'].'</a></td>';
			 echo'<td width="5%" align="left"><a>'.$row['省份'].'</a></td>';
			 echo'<td width="5%" align="left"><a>'.$row['211标识'].'</a></td>';
			 echo'<td width="5%" align="left"><a>'.$row['985标识'].'</a></td>';
			 echo'<td width="3%" align="left"><a>'.$row['录取人数'].'</a></td>';
			 echo'<td width="3%" align="left"><a>'.$row['最高分'].'</a></td> ';
			 echo'<td width="3%" align="left"><a>'.$row['最低分'].'</a></td>';
			 echo'<td width="3%" align="left"><a>'.$row['平均分'].'</a></td>  ';
			 echo'<td width="3%" align="left"><a>'.$row['差值'].'</a></td> ';
			 echo'<td width="4%" align="left"><a>'.$row['最高分省排名'].'</a></td>';
			 echo'<td width="4%" align="left"><a>'.$row['最低分省排名'].'</a></td> '; 
			 echo'<td width="4%" align="left"><a>'.$row['平均分省排名'].'</a></td> ';
			 echo'<td width="4%" align="left"><a>'.$row['年份'].'</a></td>';
			 echo'<td width="5%" align="left"><a>'.$row['批次'].'</a></td> '; 
			 echo'<td width="19%" align="left"><a>'.$row['备注'].'</a></td>';
			 echo"</tr>";

		}
		
		$oldurl = urldecode($_SERVER['REQUEST_URI']);
		$url  =  $oldurl .(strpos($oldurl ,'?')?'':"?"); 
		$ls_page =  "page=".$page;
		if (strpos($url,"php?".$ls_page."&") !== false)
		{$url = str_replace("?".$ls_page."&","?",$url);}
	    else 
		{if (strpos($url,"&".$ls_page) !== false)
			{$url = str_replace("&".$ls_page ,"",$url);}
		}
		if(strpos($url,"?") !== false)
		{$url = $url."&";}
	    else {$url = $url."?";}
		
	 //显示分页链接
    if($page==1){
        echo("第一页 ");
    }
    else
        echo("<a href=".$url."page=1>第一页</a>");
        //设置上一页连接

    if($page==1){
         echo(" 上一页 ");
    }
    else 
        echo("<a href=".$url."page=".($page-1)."> 上一页 </a>");
	
	//显示当前页码
     echo($page."/".$pagecount );
	 
        //设置下一页链接
    if($page==$pagecount){
        echo(" 下一页 ");
    }
    else 
        echo("<a href=".$url."page=".($page+1)."> 下一页 </a>");
    //设置最后一页
    if($page==$pagecount){
        echo("最后一页");
    }
    else 
        echo("<a href=".$url."page=".$pagecount.">最后一页</a>");
	/*显示上一页 下一页结束*/	
	?>
 </table>

<table>

</table>
<span style="color: red;" onclick="xianshis()">该校历年专业分数</span>|<span onclick="xianshi()">学校信息</span>
<!-- 该校历年专业分数 -->
<table style="display:block;" class="content"  width="100%" border="1" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
	
</table>
<!-- 学校信息 -->
<div style="display:none;" class="xuexxx">
	&nbsp;&nbsp;&nbsp;&nbsp;学校名称：<span id='a'>学校名称</span><br/><br/>
	&nbsp;&nbsp;&nbsp;&nbsp;学校所在地：<span id='b'>学校所在地</span><br/><br/>
	&nbsp;&nbsp;&nbsp;&nbsp;招办电话：<span id='c'>招办电话</span><br/><br/>
	&nbsp;&nbsp;&nbsp;&nbsp;电子邮箱：<span id='e'>电子邮箱</span><br/><br/>
	&nbsp;&nbsp;&nbsp;&nbsp;通信地址：<span id='f'></span><br/><br/>
	&nbsp;&nbsp;&nbsp;&nbsp;招生网址：<span id='g'></span><br/><br/>
</div>
<script src="http://libs.baidu.com/jquery/2.0.0/jquery.min.js"></script>
<script type="text/javascript">
function xianshi(){
	$(".xuexxx").show();
	 $(".content").hide();
}
function xianshis(){
	$(".xuexxx").hide();
	 $(".content").show();
}
$(function hello() {
	var text = <?php echo "'".$_GET['name']."'"; ?>;
	 $.ajax({
		type:"POST",
		url:"sql.php",
		data:{text:text},
		datatype:"json",
		success:function(res){
			var arr = $.parseJSON(res);
			var jsonObj = arr.list;
			var info = arr.info;
			$("#a").html(info.大学名称);
			$("#b").html(info.省份);
			$("#c").html(info.联系方式);
			$("#f").html(info.地址);
			$("#g").html(info.招生网址);
			var html = "";
			html += "<tr>";
		    html += '<td width="5%" align="left"><a>大学名称</a></td>'; 
			html += '<td width="5%" align="left"><a>大学及专业名称</a></td>';
			html += '<td width="5%" align="left"><a>录取人数</a></td>';
	        html += '<td width="5%" align="left"><a>最高分</a></td>';
	        html += '<td width="3%" align="left"><a>最低分</a></td>';  
			html += '<td width="3%" align="left"><a>差值</a></td> ';
	        html += '<td width="3%" align="left"><a>备注</a></td>';
	        html += '<td width="3%" align="left"><a>年份</a></td> '; 
			html += '<td width="3%" align="left"><a>批次</a></td> ';
	        html += '<td width="4%" align="left"><a>最高分省排名</a></td>';
	        html += '<td width="4%" align="left"><a>最低分省排名</a></td> '; 
			html += '<td width="4%" align="left"><a>平均分省排名</a></td> ';
	        html += "</tr>";
			for (var i = jsonObj.length - 1; i >= 0; i--) {
				html += "<tr><td width='5%' align='left'>"+jsonObj[i].大学名称+"</td>";
				html += "<td width='5%' align='left'>"+jsonObj[i].大学及专业名称+"</td>";
				html += "<td width='5%' align='left'>"+jsonObj[i].录取人数+"</td>";
				html += "<td width='5%' align='left'>"+jsonObj[i].最高分+"</td>";
				html += "<td width='5%' align='left'>"+jsonObj[i].最低分+"</td>";
				html += "<td width='5%' align='left'>"+jsonObj[i].差值+"</td>";
				html += "<td width='5%' align='left'>"+jsonObj[i].备注+"</td>";
				html += "<td width='5%' align='left'>"+jsonObj[i].年份+"</td>";
				html += "<td width='5%' align='left'>"+jsonObj[i].批次+"</td>";
				html += "<td width='5%' align='left'>"+jsonObj[i].最高分省排名+"</td>";
				html += "<td width='5%' align='left'>"+jsonObj[i].最低分省排名+"</td>";
				html += "<td width='5%' align='left'>"+jsonObj[i].平均分省排名+"</td></tr>";
			};
			$(".content").html(html);
		}
	})
 });
 
function GetQueryString(name)
{
     var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
     var r = window.location.search.substr(1).match(reg);
     if(r!=null)return  unescape(r[2]); return null;
}
</script>
<script language="javascript">

function getQueryString(){
     var result = location.search.match(new RegExp("[\?\&][^\?\&]+=[^\?\&]+","g"));
     if(result == null){
         return "";
     }
     for(var i = 0; i < result.length; i++){
         result[i] = result[i].substring(1);
     }
     return result;
}

function goSort(name,value){
	  //if(${name}) ${name}.value = value ;
    var string_array = getQueryString();
    var oldUrl = (document.URL.indexOf("yx.php")==-1)?document.URL+"yx.php":document.URL;
    var newUrl;
    if(string_array.length>0)//如果已经有筛选条件
    {   var repeatField = false;
        for(var i=0;i<string_array.length;i++){
            if(!(string_array[i].indexOf(name)==-1)){
                repeatField = true;//如果有重复筛选条件，替换条件值
                newUrl = oldUrl.replace(string_array[i],name+"="+value);
            }
        }
        //如果没有重复的筛选字段
        if(repeatField == false){
            newUrl = oldUrl+"&"+name+"="+value;
        }
    }else{//如果还没有筛选条件
        newUrl = oldUrl+"?"+name+"="+value;
    }
    //跳转
    window.location = newUrl;
}
function setSelected(name,value){
    var all_li = $("#"+name).find("li");
    //清除所有li标签的selected类
    all_li.each(function(){
        $(this).removeClass("selected");
    });
    //为选中的li增加selected类
    all_li.eq(value).addClass("selected");
    
}
$(document).ready(function(){
    var string_array = getQueryString();
    for(var i=0;i<string_array.length;i++){
        var tempArr = string_array[i].split("=");
        setSelected(tempArr[0],tempArr[1]);//设置选中的筛选条件
    }
});

function linNianFenShu(schoolname)
{
	var sql_lnfs = sprintf("select * from like_data where 大学名称 = '%s';",schoolname); 
    return sql_lnfs;
}
</script> 


</body>
</html>
