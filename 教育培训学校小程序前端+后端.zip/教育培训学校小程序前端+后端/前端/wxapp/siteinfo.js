var i = {
    uniacid: "3",
    acid: "3",
    multiid: "0",
    version: "1.7.4",
    siteroot: "https://www.lanrenzhijia.com/app/index.php",
    design_method: "3"
};

module.exports = i;