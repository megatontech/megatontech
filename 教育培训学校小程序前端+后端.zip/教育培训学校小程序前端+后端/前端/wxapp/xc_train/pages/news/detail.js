getApp();

var n = require("../common/common.js");

Page({
    data: {},
    onLoad: function(n) {},
    onReady: function() {},
    onShow: function() {
        n.audio_end(this);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});